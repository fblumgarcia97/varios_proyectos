
const mongoose=require("mongoose");

mongoose.connect("mongodb://localhost:27017/fruitsDB")

const fruitsSchema=new mongoose.Schema({
name:{
    type:String,
    required:[true,"check your entry GIL"]
},
rating:{
    type:Number,
    min:1,
    max:10
},
review:String
})

const Fruit=mongoose.model("Fruit",fruitsSchema);

const fruit=new Fruit({
    //name:"apple",
    rating:5,
    review:"Pretty solid as a fruit"
});

//fruit.save();

const personSchema=new mongoose.Schema({
    name:String,
    age:Number,
    favouriteFruit:fruitsSchema
});
const Person=mongoose.model("Person",personSchema);
const pinneaple=new Fruit({
    name:"Pinneaple",
    rating:9,
    review:"Great fruit"
});
//pinneaple.save();
const person=new Person({
    name:"Emmy",
    age:57,
    favouriteFruit:pinneaple
});
//person.save();

const orange=new Fruit({
    name:"Orange",
    rating:6,
    review:"To sour for me"
});
const banana=new Fruit({
    name:"Banana",
    rating:4,
    review:"To weird to me"
});
 /*Fruit.insertMany([orange,banana],function(err){
     if(err){
         console.log(err)
     }else{
         console.log("Succesfully")
     }
 });*/

 /*Fruit.find(function(err,fruits){
    if(err){
        console.log(err);
    }else{
        fruits.forEach(fruit => {
            console.log(fruit.name);
        });
    }
    //mongoose.connection.close();
 });*/

/*Fruit.updateOne({name:"Banana"},{rating:3},function(err){
     if(err){
         console.log(err)
     }else{
         console.log("Update")
     }
 });*/

/*Fruit.deleteOne({name:"Banana"},function(err){
     if(err){
         console.log(err);
     }else{
         console.log("delete");
     }
 });*/

Person.updateOne({name:"John"},{favouriteFruit:{name:"apple"}},function(err){
     if(err){
         console.log(err);
     }else{
         console.log("update");
     }
 });