const express=require("express");
const request=require("request");
const bodyParser=require("body-parser");
const https=require("https");
const { options } = require("request");
const { response } = require("express");

const app=express();
app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended:true}));

app.get("/",function(req,res){//Saca la pagina principalS
    res.sendFile(__dirname+"/signup.html")
})
app.post("/",function(req,res){
    const firstName=req.body.firstName;//Saca la info y la pone en data
    const lastName=req.body.lastName;
    const email=req.body.email;
    const data={
        members:[{
            email_address:email,
            status:"subscribed",
            merge_fields:{
                FNAME:firstName,
                LNAME:lastName  
            }
        }]
    };
    const jsonData=JSON.stringify(data);//Convierte a estilo JSON
    const url="https://us14.api.mailchimp.com/3.0/lists/61f368290a";
    const options={
        method:"POST",
        auth:"fblumgarcia:s2a4df621b7072f9d80d4b8d014939f9d-us14"
    };
    const request=https.request(url,options,function(response){
        if(response.statusCode==200){//Si esta correcto llama esta pag
            res.sendFile(__dirname+"/success.html")
        }else{
            res.sendFile(__dirname+"/failure.html")
        }
    /*    response.on("data",function(data){//para mostrar en consola
            console.log(JSON.parse(data));
        });*/

    });
    request.write(jsonData);//escribe la info  y abajo la envia
    request.end();
});

app.post("/failure",function(req,res){//Esto es para redirigir a la página principal
    res.redirect("/");
})
app.listen(process.env.PORT||3000,function(){//Pober la función en un puerto
    console.log("Server running in port 3000")
})


//api key mailchim
//2a4df621b7072f9d80d4b8d014939f9d-us14

//list id
//61f368290a